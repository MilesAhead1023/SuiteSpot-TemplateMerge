Monorepo layout. SDK as submodule. Build Release|Win32. Post-build copies DLL to %AppData%/bakkesmod/bakkesmod/plugins.
